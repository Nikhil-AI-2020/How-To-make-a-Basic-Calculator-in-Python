print("    For Addition")
x=int(input("x = "))
y=int(input("y = "))
z=x+y
print("Your answer is = ",z)

print("    For Subraction")
x=int(input("x = "))
y=int(input("y = "))
z=x-y
print("Your answer is = ",z)

print("    For Multiplication")
x=int(input("x = "))
y=int(input("y = "))
z=x*y
print("Your answer is = ",z)

print("    For Division")
x=int(input("x = "))
y=int(input("y = "))
z=x/y
print("Your answer is = ",z)
